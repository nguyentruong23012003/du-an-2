
public class Contact {
    private String soDienThoai;
    private String nhom;
    private String hoTen;
    private String gioiTinh;
    private String diaChi;
    private String ngaySinh;
    private String email;

    public Contact(String soDienThoai, String nhom, String hoTen, String gioiTinh,
                   String diaChi, String ngaySinh, String email) {
        this.soDienThoai = soDienThoai;
        this.nhom = nhom;
        this.hoTen = hoTen;
        this.gioiTinh = gioiTinh;
        this.diaChi = diaChi;
        this.ngaySinh = ngaySinh;
        this.email = email;
    }


    public String getSoDienThoai() { return soDienThoai; }
    public String getNhom() { return nhom; }
    public String getHoTen() { return hoTen; }
    public String getGioiTinh() { return gioiTinh; }
    public String getDiaChi() { return diaChi; }
    public String getNgaySinh() { return ngaySinh; }
    public String getEmail() { return email; }


    public void setNhom(String nhom) { this.nhom = nhom; }
    public void setHoTen(String hoTen) { this.hoTen = hoTen; }
    public void setGioiTinh(String gioiTinh) { this.gioiTinh = gioiTinh; }
    public void setDiaChi(String diaChi) { this.diaChi = diaChi; }
    public void setNgaySinh(String ngaySinh) { this.ngaySinh = ngaySinh; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return String.format("%-12s %-12s %-20s %-8s %-25s %-12s %s",
                soDienThoai, nhom, hoTen, gioiTinh, diaChi,
                ngaySinh.isEmpty() ? "Chưa có" : ngaySinh, email);
    }

    public String toCSV() {
        return soDienThoai + "," + nhom + "," + hoTen + "," + gioiTinh + "," +
                diaChi + "," + ngaySinh + "," + email;
    }
}