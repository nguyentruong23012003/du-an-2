
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        PhoneBook pb = new PhoneBook();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("=======================================");
            System.out.println("     CHƯƠNG TRÌNH QUẢN LÝ DANH BẠ");
            System.out.println("=======================================");
            System.out.println("1. Xem danh sách");
            System.out.println("2. Thêm mới");
            System.out.println("3. Cập nhật");
            System.out.println("4. Xóa");
            System.out.println("5. Tìm kiếm");
            System.out.println("6. Đọc từ file");
            System.out.println("7. Ghi vào file");
            System.out.println("8. Thoát");
            System.out.print("Chọn chức năng: ");

            String chon = sc.nextLine().trim();

            switch (chon) {
                case "1" -> pb.xemDanhSach();
                case "2" -> pb.themMoi();
                case "3" -> pb.capNhat();
                case "4" -> pb.xoa();
                case "5" -> pb.timKiem();
                case "6" -> pb.docTuFile();
                case "7" -> pb.ghiVaoFile();
                case "8" -> { System.out.println("Tạm biệt!"); return; }
                default -> System.out.println("Lựa chọn không hợp lệ!");
            }
        }
    }
}