
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class PhoneBook {
    private List<Contact> contacts = new ArrayList<>();
    private Scanner sc = new Scanner(System.in);
    private static final String FILE = "data/contacts.csv";

    // 1. Xem danh sách
    public void xemDanhSach() {
        if (contacts.isEmpty()) { System.out.println("Danh bạ trống!"); return; }
        for (int i = 0; i < contacts.size(); i++) {
            if (i % 5 == 0) System.out.println("\n=== Trang " + (i/5 + 1) + " ===");
            System.out.println((i+1) + ". " + contacts.get(i));
            if (i % 5 == 4 && i != contacts.size()-1) {
                System.out.print("Nhấn Enter để xem tiếp..."); sc.nextLine();
            }
        }
    }

    // 2 Them moi
    public void themMoi() {
        System.out.println("\n--- Thêm mới danh bạ ---");
        String phone = nhapPhone();
        if (timTheoPhone(phone) != null) { System.out.println("Số điện thoại đã tồn tại!"); return; }

        contacts.add(new Contact(
                phone,
                nhap("Nhóm: "),
                nhap("Họ tên: "),
                nhap("Giới tính: "),
                nhap("Địa chỉ: "),
                input("Ngày sinh (yyyy-MM-dd, Enter để trống): "),
                nhapEmail()
        ));
        System.out.println("Thêm thành công!");
    }

    // 3 Cap nhat
    public void capNhat() {
        System.out.println("\n--- Cập nhật danh bạ ---");
        while (true) {
            System.out.print("Nhập số điện thoại (Enter để thoát): ");
            String phone = sc.nextLine().trim();
            if (phone.isEmpty()) return;
            Contact c = timTheoPhone(phone);
            if (c == null) { System.out.println("Không tìm thấy!"); continue; }

            System.out.println("Hiện tại: " + c);
            c.setNhom(nhapOpt("Nhóm", c.getNhom()));
            c.setHoTen(nhapOpt("Họ tên", c.getHoTen()));
            c.setGioiTinh(nhapOpt("Giới tính", c.getGioiTinh()));
            c.setDiaChi(nhapOpt("Địa chỉ", c.getDiaChi()));
            String ns = input("Ngày sinh [" + (c.getNgaySinh().isEmpty()?"Chưa có":c.getNgaySinh()) + "]: ");
            if (!ns.isEmpty()) c.setNgaySinh(ns);
            c.setEmail(nhapEmailOpt(c.getEmail()));
            System.out.println("Cập nhật thành công!");
            return;
        }
    }

    // 4. Xoa
    public void xoa() {
        System.out.println("\n--- Xóa danh bạ ---");
        while (true) {
            System.out.print("Nhập số điện thoại (Enter để thoát): ");
            String phone = sc.nextLine().trim();
            if (phone.isEmpty()) return;
            Contact c = timTheoPhone(phone);
            if (c == null) { System.out.println("Không tìm thấy!"); continue; }
            System.out.println("Tìm thấy: " + c);
            System.out.print("Xác nhận xóa? (Y/N): ");
            if (sc.nextLine().trim().equalsIgnoreCase("Y")) {
                contacts.remove(c);
                System.out.println("Xóa thành công!");
            } else System.out.println("Đã hủy.");
            return;
        }
    }

    //Tim Kiem
    public void timKiem() {
        System.out.print("\nNhập tên hoặc số điện thoại: ");
        String key = sc.nextLine().trim().toLowerCase();
        if (key.isEmpty()) return;
        System.out.println("Kết quả tìm kiếm:");
        boolean found = false;
        for (Contact c : contacts) {
            if (c.getSoDienThoai().contains(key) || c.getHoTen().toLowerCase().contains(key)) {
                System.out.println(c); found = true;
            }
        }
        if (!found) System.out.println("Không tìm thấy!");
    }

    //6 .Doc File
    public void docTuFile() {
        File f = new File(FILE);
        System.out.println("Tìm file tại: " + f.getAbsolutePath());

        if (!f.exists()) {
            System.out.println("Không tìm thấy file!");
            System.out.print("Tạo file mẫu? (Y/N): ");
            if (sc.nextLine().trim().equalsIgnoreCase("Y")) taoFileMau();
            else { System.out.println("Hủy."); return; }
            return;
        }

        System.out.print("Xóa dữ liệu cũ và đọc file? (Y/N): ");
        if (!sc.nextLine().trim().equalsIgnoreCase("Y")) return;

        contacts.clear();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            br.readLine(); // bỏ header
            String line; int count = 0;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] p = line.split(",", -1);
                if (p.length >= 7) {
                    contacts.add(new Contact(p[0].trim(), p[1].trim(), p[2].trim(), p[3].trim(), p[4].trim(), p[5].trim(), p[6].trim()));
                    count++;
                }
            }
            System.out.println("Đọc thành công " + count + " liên hệ!");
        } catch (Exception e) { System.out.println("Lỗi đọc file: " + e.getMessage()); }
    }


    private void taoFileMau() {
        new File("data").mkdirs();
        try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(FILE), StandardCharsets.UTF_8))) {
            bw.write("Số điện thoại,Nhóm,Họ tên,Giới tính,Địa chỉ,Ngày sinh,Email\n");
            bw.write("0123456789,Bạn bè,Nguyễn Văn A,Nam,Hà Nội,2000-01-01,a@gmail.com\n");
            bw.write("0987654321,Gia đình,Trần Thị B,Nữ,TP.HCM,1999-12-25,b@yahoo.com\n");
            bw.write("0901234567,Đồng nghiệp,Lê Văn C,Nam,Đà Nẵng,,c@example.com\n");
            System.out.println("TẠO FILE MẪU THÀNH CÔNG tại: " + new File(FILE).getAbsolutePath());
        } catch (Exception e) { System.out.println("Lỗi tạo file mẫu!"); }
    }

   //7 Ghi File
    public void ghiVaoFile() {
        System.out.print("Ghi đè file? (Y/N): ");
        if (!sc.nextLine().trim().equalsIgnoreCase("Y")) { System.out.println("Hủy."); return; }
        new File("data").mkdirs();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE))) {
            bw.write("Số điện thoại,Nhóm,Họ tên,Giới tính,Địa chỉ,Ngày sinh,Email\n");
            for (Contact c : contacts) { bw.write(c.toCSV() + "\n"); }
            System.out.println("Lưu thành công " + contacts.size() + " liên hệ!");
        } catch (Exception e) { System.out.println("Lỗi ghi file!"); }
    }

    //Tim Kiem SDT
    private Contact timTheoPhone(String p) {
        for (Contact c : contacts) if (c.getSoDienThoai().equals(p)) return c;
        return null;
    }
    private String nhapPhone() {
        while (true) {
            System.out.print("Số điện thoại (bắt đầu 0, 10-11 số): ");
            String s = sc.nextLine().trim();
            if (s.matches("0\\d{9,10}")) return s;
            System.out.println("Sai định dạng!");
        }
    }
    private <Overridesreturn> String nhap(String msg) {
        while (true) { System.out.print(msg); String s = sc.nextLine().trim(); if (!s.isEmpty()) {
        }
        }
    }
    private String input(String msg) { System.out.print(msg); return sc.nextLine().trim(); }
    private String nhapEmail() {
        while (true) {
            System.out.print("Email (Enter để trống): ");
            String e = sc.nextLine().trim();
            if (e.isEmpty() || e.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) return e;
            System.out.println("Email sai!");
        }
    }
    private String nhapOpt(String msg, String cur) {
        System.out.print(msg + " [" + cur + "]: ");
        String s = sc.nextLine().trim();
        return s.isEmpty() ? cur : s;
    }
    private String nhapEmailOpt(String cur) {
        System.out.print("Email [" + cur + "]: ");
        String e = sc.nextLine().trim();
        if (e.isEmpty()) return cur;
        if (e.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) return e;
        System.out.println("Email sai → giữ nguyên."); return cur;
    }
}